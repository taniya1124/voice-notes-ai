import speech_recognition as sr
import os

recognizer = sr.Recognizer()
note_number = 1  # Start from voice_1.txt

while True:
    with sr.Microphone() as source:
        print(f"\n🎤 Recording voice note #{note_number}... (Say 'stop recording' to end)")
        audio = recognizer.listen(source)

        try:
            # Convert audio to text
            text = recognizer.recognize_google(audio)
            print(f"📝 You said: {text}")

            # Stop condition
            if "stop recording" in text.lower():
                print("🛑 Stopping voice note recording. Goodbye!")
                break

            # Save each note to a separate file
            filename = f"voice_{note_number}.txt"
            with open(filename, "w") as f:
                f.write(text)

            print(f"✅ Saved to file: {filename}")
            note_number += 1  # Move to the next note

        except sr.UnknownValueError:
            print("❌ Sorry, could not understand the audio.")
        except sr.RequestError:
            print("❌ Failed to connect to speech service.")
